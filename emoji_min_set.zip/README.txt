Minimal emoji set (20 SVGs)
--------------------------------
Lightweight, non-official emoji-style SVGs to use locally with your chat.
Filenames follow Twemoji codepoint naming, so they drop in with your current code.

NOTE: These are NOT the official Twemoji artwork. If you want the official look (CC-BY 4.0),
replace these files with the corresponding Twemoji SVG assets using the exact same filenames.

Included files:
1f600.svg (😀), 1f602.svg (😂), 1f60a.svg (😊), 1f609.svg (😉), 1f60d.svg (😍),
1f60e.svg (😎), 1f62d.svg (😭), 1f621.svg (😡), 1f44d.svg (👍), 1f64f.svg (🙏),
1f44f.svg (👏), 1f525.svg (🔥), 2728.svg (✨), 1f389.svg (🎉), 2764-fe0f.svg (❤️),
1f499.svg (💙), 1f49a.svg (💚), 1f49b.svg (💛), 1f605.svg (😅), 1f914.svg (🤔).
